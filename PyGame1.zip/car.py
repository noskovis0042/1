import pygame
import os
import sys
from PIL.ImageOps import mirror


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


if __name__ == '__main__':
    # метод init
    pygame.init()
    size = width, height = 600, 95
    screen = pygame.display.set_mode(size)
    pygame.display.set_caption('Машинка')
    # fps = 30
    # clock = pygame.time.Clock()

    all_sprites = pygame.sprite.Group()


    class Car(pygame.sprite.Sprite):
        def __init__(self, image, position, step):
            super().__init__()
            self.original_image = image
            self.image = self.original_image
            self.rect = self.image.get_rect(center=position)
            self.step = step

        def update(self):
            self.rect.move_ip(self.step, 0)
            if self.rect.right > width or self.rect.left < 0:
                self.step = -self.step
                self.image = pygame.transform.flip(self.image, True, False)


    # car = pygame.sprite.Sprite(all_sprites)
    image_ = load_image('car.png')
    car = Car(image_, (75, 50), 4)
    all_sprites.add(car)

    # car.rect.x, car.rect.y = 0, 0
    clock = pygame.time.Clock()
    running = True
    while running:
        screen.fill(pygame.Color('white'))

        # перебор событий
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # основной код
        car.update()
        all_sprites.draw(screen)
        clock.tick(30)

        # отрисовка кадра
        pygame.display.flip()
    pygame.quit()
